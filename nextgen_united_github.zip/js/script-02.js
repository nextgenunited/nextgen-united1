/* Extracted from original <script> */

/* ==================================================
   PRESENÇAS + GOOGLE LOGIN + FIRESTORE
   CONFIGURAÇÃO NECESSÁRIA:
   1) Criar um projeto Firebase.
   2) Ativar Authentication > Google.
   3) Criar Firestore Database.
   4) Colar aqui os dados da Web App do Firebase.
   5) Substituir os dois emails abaixo.
================================================== */
const FIREBASE_CONFIG = {
  apiKey: "COLOCA_AQUI_API_KEY",
  authDomain: "COLOCA_AQUI.firebaseapp.com",
  projectId: "COLOCA_AQUI",
  storageBucket: "COLOCA_AQUI.firebasestorage.app",
  messagingSenderId: "COLOCA_AQUI",
  appId: "COLOCA_AQUI"
};
const ADMIN_EMAILS = {
  teddy: "EMAIL_DO_TEDDY",
  martins: "EMAIL_DO_MARTINS"
};

(function(){
  const statusOrder=['empty','present','late','absent','unexcused'];
  const statusText={empty:'SEM REGISTO',present:'PRESENÇA',late:'ATRASO',absent:'FALTA',unexcused:'SEM AVISO'};
  const dayNames=['DOM','SEG','TER','QUA','QUI'];
  let attendanceWeekStart=startOfSunday(new Date());
  let attendanceData={};
  let currentUser=null;
  let canEdit=sessionStorage.getItem('attendanceAdmin')==='1';
  let cloudReady=false;

  function startOfSunday(date){const d=new Date(date.getFullYear(),date.getMonth(),date.getDate());d.setDate(d.getDate()-d.getDay());return d;}
  function dateKey(date){return date.getFullYear()+'-'+String(date.getMonth()+1).padStart(2,'0')+'-'+String(date.getDate()).padStart(2,'0');}
  function formatDate(date){return String(date.getDate()).padStart(2,'0')+'/'+String(date.getMonth()+1).padStart(2,'0');}
  function formatWeekLabel(){const end=new Date(attendanceWeekStart);end.setDate(end.getDate()+4);return 'TREINOS · '+formatDate(attendanceWeekStart)+' — '+formatDate(end);}
  function getPlayers(){if(typeof playersData!=='undefined')return Object.keys(playersData);return ['MOSCA','NIGHTFACE','MJ_','BANJAQUI','LOURO','TXUBAS','DIOGO','SALES','DUDA','RAFAEL','WOLF','KERMIT','ROGERIO','PEDRO','DOLLY','MARTINS','TEDDY'];}
  function displayPlayerName(name){if(name==='MJ_')return 'MJ';if(name==='MARTINS')return 'MARTINS (P)';if(name==='TEDDY')return 'TEDDY (C)';return name;}
  function playerPosition(name){if(typeof playersData!=='undefined'&&playersData[name])return playersData[name].position;return '';}
  function currentStatus(player,date){const key=dateKey(date);return(attendanceData[key]&&attendanceData[key][player])||'empty';}
  function setAuthUI(){
    if(sessionStorage.getItem('attendanceAdmin')==='1'){ currentUser={email:'miguelrrangelo12@gmail.com',displayName:'Teddy'}; canEdit=true; }
    let box=document.getElementById('attendanceAuthBox');
    if(!box){
      box=document.createElement('div');box.id='attendanceAuthBox';box.style.cssText='margin:0 0 18px;padding:14px 16px;border:1px solid rgba(255,255,255,.12);border-radius:12px;background:rgba(255,255,255,.04);display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;';
      const wrap=document.querySelector('#presencas .attendance-wrap'); if(wrap) wrap.insertBefore(box,wrap.firstElementChild);
    }
    if(!currentUser){box.innerHTML='<div><strong>🔒 Presenças protegidas</strong><br><span style="opacity:.7">Só o Teddy e o Martins podem alterar os registos.</span></div><button class="attendance-btn" id="googleLoginBtn" type="button">ENTRAR COM GOOGLE</button>';document.getElementById('googleLoginBtn').onclick=googleLogin;}
    else {const role=currentUser.email?.toLowerCase()===ADMIN_EMAILS.teddy.toLowerCase()?'ADMIN':currentUser.email?.toLowerCase()===ADMIN_EMAILS.martins.toLowerCase()?'CO-ADMIN':'CONSULTA';box.innerHTML='<div><strong>👤 '+(currentUser.displayName||currentUser.email)+'</strong><br><span style="opacity:.7">Modo '+role+(canEdit?' · pode editar':' · apenas consulta')+'</span></div><button class="attendance-btn" type="button" id="googleLogoutBtn">SAIR</button>';document.getElementById('googleLogoutBtn').onclick=googleLogout;}
  }
  function renderAttendance(){
    const label=document.getElementById('attendanceWeekLabel'),head=document.getElementById('attendanceHead'),body=document.getElementById('attendanceBody');if(!label||!head||!body)return;
    label.textContent=formatWeekLabel();let h='<tr><th>JOGADOR</th>';for(let i=0;i<5;i++){const d=new Date(attendanceWeekStart);d.setDate(d.getDate()+i);h+='<th>'+dayNames[i]+'<br><span style="opacity:.55">'+formatDate(d)+'</span></th>';}h+='<th>RESUMO</th></tr>';head.innerHTML=h;
    body.innerHTML=getPlayers().map(function(player){const pos=playerPosition(player);const posCode=(pos||'').split('·')[0].trim().toUpperCase();const posClass=player==='MARTINS'?'president':(player==='TEDDY'?'captain':(posCode==='GR'?'goalkeeper':(['DD','DC','DE'].includes(posCode)?'defender':(['MC','MD','ME'].includes(posCode)?'midfielder':(['PL','AV','AT'].includes(posCode)?'attacker':'')))));let row='<tr class="attendance-row '+posClass+'"><td class="attendance-player">'+(playersData[player]&&playersData[player].photo?'<img class="section-player-photo" src="'+playersData[player].photo+'" alt="" loading="lazy">':'')+'<span class="attendance-player-info"><span>'+displayPlayerName(player)+'</span><span class="attendance-pos">'+pos+'</span></span></td>';const counts={present:0,late:0,absent:0,unexcused:0};for(let i=0;i<5;i++){const d=new Date(attendanceWeekStart);d.setDate(d.getDate()+i);const st=currentStatus(player,d);if(counts[st]!==undefined)counts[st]++;const click=canEdit?'onclick="cycleAttendanceCell(\''+player.replace(/'/g,"\\'")+'\','+d.getTime()+')"':'';row+='<td class="attendance-cell" title="'+statusText[st]+'" '+click+'><span class="attendance-dot '+st+'"></span><span class="attendance-status-text">'+statusText[st]+'</span></td>';}row+='<td><div class="attendance-summary"><span class="attendance-mini">🟢 '+counts.present+'</span><span class="attendance-mini">🟡 '+counts.late+'</span><span class="attendance-mini">🔴 '+counts.absent+'</span><span class="attendance-mini">🟣 '+counts.unexcused+'</span></div></td></tr>';return row;}).join('');
    setAuthUI();
  }
  async function googleLogin(){if(!cloudReady){alert('O login ainda não está configurado. É preciso ligar este site ao projeto Firebase.');return;}try{const provider=new firebase.auth.GoogleAuthProvider();await firebase.auth().signInWithPopup(provider);}catch(e){alert('Não foi possível entrar com Google: '+e.message);}}
  async function googleLogout(){if(window.firebase)await firebase.auth().signOut();}
  const LOCAL_PRESENÇAS_KEY='trainingAttendanceData_TEDDY_V2';

  async function loadWeekFromCloud(){
    try{
      const raw=localStorage.getItem(LOCAL_PRESENÇAS_KEY);
      attendanceData=raw?JSON.parse(raw)||{}:{};
    }catch(e){
      attendanceData={};
      console.error('Erro a carregar presenças:',e);
    }
    renderAttendance();
  }

  async function saveWeekToCloud(){
    if(!canEdit)return;
    try{
      localStorage.setItem(LOCAL_PRESENÇAS_KEY,JSON.stringify(attendanceData));
      localStorage.setItem('trainingAttendanceData',JSON.stringify(attendanceData));
    }catch(e){
      console.error('Erro a guardar presenças:',e);
      throw e;
    }
  }

  window.saveAttendanceData=async function(){
    if(!canEdit){
      alert('Entra primeiro no MODO ADMIN para guardar as presenças.');
      return;
    }
    try{
      localStorage.setItem(LOCAL_PRESENÇAS_KEY,JSON.stringify(attendanceData));
      localStorage.setItem('trainingAttendanceData',JSON.stringify(attendanceData));
      const msg=document.getElementById('attendanceSaveMessage');
      if(msg){
        msg.textContent='✓ Presenças guardadas com sucesso';
        msg.style.display='inline-block';
        clearTimeout(window.__saveMsgTimer);
        window.__saveMsgTimer=setTimeout(()=>msg.style.display='none',2200);
      }
    }catch(e){
      console.error(e);
      alert('Não foi possível guardar as presenças: '+e.message);
    }
  };

  async function cycleStatus(player,date){if(!canEdit)return;const key=dateKey(date);if(!attendanceData[key])attendanceData[key]={};const current=currentStatus(player,date);const next=statusOrder[(statusOrder.indexOf(current)+1)%statusOrder.length];if(next==='empty')delete attendanceData[key][player];else attendanceData[key][player]=next;renderAttendance();try{localStorage.setItem(LOCAL_PRESENÇAS_KEY,JSON.stringify(attendanceData));localStorage.setItem('trainingAttendanceData',JSON.stringify(attendanceData));}catch(e){console.error(e);alert('Não foi possível guardar esta alteração.');}}
  window.cycleAttendanceCell=function(player,timestamp){cycleStatus(player,new Date(timestamp));};
  window.changeAttendanceWeek=function(days){attendanceWeekStart.setDate(attendanceWeekStart.getDate()+days);loadWeekFromCloud();};
  window.goAttendanceToday=function(){attendanceWeekStart=startOfSunday(new Date());loadWeekFromCloud();};
  window.clearAttendanceWeek=async function(){if(!canEdit)return;if(!confirm('Queres limpar todos os registos desta semana?'))return;attendanceData={};renderAttendance();try{await saveWeekToCloud();}catch(e){console.error(e);}};
  window.renderAttendance=renderAttendance;
  window.addEventListener('adminModeChanged', function(e){ canEdit=!!e.detail; if(canEdit){currentUser={email:'miguelrrangelo12@gmail.com',displayName:'Teddy'};} else {currentUser=null;} renderAttendance(); });
  window.addEventListener('DOMContentLoaded',function(){
    setTimeout(function(){loadWeekFromCloud();},100);
  });


  function loadFirebaseScripts(){
    if(FIREBASE_CONFIG.apiKey.startsWith('COLOCA_AQUI')){setAuthUI();renderAttendance();return;}
    const a=document.createElement('script');a.src='https://www.gstatic.com/firebasejs/10.14.1/firebase-app-compat.js';a.onload=function(){
      const b=document.createElement('script');b.src='https://www.gstatic.com/firebasejs/10.14.1/firebase-auth-compat.js';b.onload=function(){
        const c=document.createElement('script');c.src='https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore-compat.js';c.onload=function(){
          firebase.initializeApp(FIREBASE_CONFIG);cloudReady=true;
          firebase.auth().onAuthStateChanged(async function(user){currentUser=user;const email=(user?.email||'').toLowerCase();canEdit=!!user&&(email===ADMIN_EMAILS.teddy.toLowerCase()||email===ADMIN_EMAILS.martins.toLowerCase());await loadWeekFromCloud();});
        };document.head.appendChild(c);
      };document.head.appendChild(b);
    };document.head.appendChild(a);
  }
  loadFirebaseScripts();
})();
