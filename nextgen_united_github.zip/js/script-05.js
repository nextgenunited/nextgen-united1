/* Extracted from original <script id="history-fix-js"> */

(function(){
  function getHistorySection(){
    return document.getElementById('tournamentHistorySection') ||
      document.getElementById('historicoTorneios') ||
      document.querySelector('#historico-torneios, .tournament-history, .historico-torneios, [data-section="tournament-history"]');
  }
  window.openTournamentHistory = function(ev){
    if(ev) ev.preventDefault();
    showPage('historico-torneios');
    var page=document.getElementById('historico-torneios');
    if(page) page.classList.add('active');
    return false;
  };
  document.addEventListener('DOMContentLoaded',function(){
    document.querySelectorAll('.tournament-game').forEach(function(el){
      function go(){ 
        var n=el.getAttribute('data-match');
        if(window.openMatch) window.openMatch(n);
        else if(window.openTournamentMatch) window.openTournamentMatch(n);
      }
      el.addEventListener('click',go);
      el.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();go();}});
    });
  });
})();
