/* Extracted from original <script id="opponent-badge-update"> */

(function(){
  const oldOpen = window.openMatch;
  if(typeof oldOpen !== 'function') return;
  const names = {1:'MSC',2:'VDC',3:'RDF',4:'VFC'};
  window.openMatch = function(id){
    const result = oldOpen(id);
    const el = document.getElementById('modalAwayVisual');
    if(el){
      const code = names[String(id)] || 'FC';
      el.innerHTML = '<span class="badge-crown">◆</span><strong>'+code+'</strong>';
      el.classList.add('opponent-badge');
    }
    return result;
  };
})();
