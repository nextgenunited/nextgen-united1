/* Extracted from original <script id="section-player-photos"> */

(function(){
  function addSectionPhotos(){
    if(typeof playersData==='undefined') return;
    document.querySelectorAll('.stats-row').forEach(function(row){
      if(row.querySelector('.section-player-photo')) return;
      var strong=row.querySelector('strong'); if(!strong) return;
      var key=strong.textContent.trim().replace(/\s*\(P\)|\s*\(C\)/g,'');
      var data=playersData[key]; if(!data || !data.photo) return;
      var wrap=document.createElement('div'); wrap.className='stats-player-name';
      var img=document.createElement('img'); img.className='section-player-photo'; img.src=data.photo; img.alt=''; img.loading='lazy';
      strong.parentNode.insertBefore(wrap,strong); wrap.appendChild(img); wrap.appendChild(strong);
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',addSectionPhotos); else addSectionPhotos();
})();
