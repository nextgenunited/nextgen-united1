/* Extracted from original <script id="final-tournament-modal-data"> */

(function(){
  const matches = {
    1:{title:'JOGO 01 · VS MARITIMO SC',score:'3–1',result:'VITÓRIA',away:'MARITIMO SC',badge:'MSC',
       events:[{type:'scorer',label:'GOLO',name:'Pedro'},{type:'scorer',label:'GOLO',name:'Dolly'},{type:'scorer',label:'GOLO',name:'Auto golo'}]},
    2:{title:'JOGO 02 · VS VALE DO DOURO DC',score:'1–0',result:'VITÓRIA',away:'VALE DO DOURO DC',badge:'VDC',
       events:[{type:'scorer',label:'GOLO',name:'Teddy'},{type:'assist',label:'ASSISTÊNCIA',name:'Pedro'}]},
    3:{title:'JOGO 03 · VS R DAS FONTES FC',score:'6–0',result:'VITÓRIA',away:'R DAS FONTES FC',badge:'RDF',
       events:[{type:'scorer',label:'GOLOS',name:'Nightface ×4'},{type:'scorer',label:'GOLOS',name:'Teddy ×2'}]},
    4:{title:'JOGO 04 · VS VISEU ESPORTS',score:'0–0',result:'DERROTA',away:'VISEU ESPORTS',badge:'VFC',
       note:'Penáltis: 7–8 · derrota nos penáltis',events:[]}
  };
  function openMatch(match){
    const m=matches[match]; if(!m) return;
    const modal=document.getElementById('matchModal'); if(!modal) return;
    const title=document.getElementById('matchModalTitle');
    const score=document.getElementById('modalScore');
    const result=document.getElementById('modalResult');
    const away=document.getElementById('modalAwayName');
    const events=document.getElementById('modalEvents');
    const note=document.getElementById('modalNote');
    const awayVisual=document.getElementById('modalAwayVisual');
    if(title) title.textContent=m.title;
    if(score) score.textContent=m.score;
    if(result) result.textContent=m.result;
    if(away) away.textContent=m.away;
    if(awayVisual){ awayVisual.textContent=m.badge||'FC'; }
    if(events) events.innerHTML=m.events.map(e =>
      '<div class="modal-event '+e.type+'"><strong>'+e.label+'</strong><span>'+e.name+'</span></div>'
    ).join('');
    if(note) note.textContent=m.note||'';
    modal.setAttribute('aria-hidden','false');
    modal.classList.add('open');
  }
  function closeMatch(){
    const modal=document.getElementById('matchModal'); if(!modal)return;
    modal.setAttribute('aria-hidden','true'); modal.classList.remove('open');
  }
  document.addEventListener('DOMContentLoaded',function(){
    document.querySelectorAll('.tournament-game').forEach(btn=>{
      btn.addEventListener('click',()=>openMatch(btn.dataset.match));
      btn.addEventListener('keydown',e=>{ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); openMatch(btn.dataset.match); } });
    });
    const close=document.getElementById('matchModalClose'); if(close) close.addEventListener('click',closeMatch);
    const modal=document.getElementById('matchModal');
    if(modal) modal.addEventListener('click',e=>{if(e.target===modal)closeMatch();});
  });
})();
