/* Extracted from original <script id="nextgen-history-working-fix"> */

(function(){
  const matchData={
    1:{title:'JOGO 01 · VS MARITIMO SC',score:'3–1',result:'VITÓRIA',away:'MARITIMO SC',badge:'MSC',events:[['GOLO','Pedro'],['GOLO','Dolly'],['GOLO','Auto golo']]},
    2:{title:'JOGO 02 · VS VALE DO DOURO DC',score:'1–0',result:'VITÓRIA',away:'VALE DO DOURO DC',badge:'VDC',events:[['GOLO','Teddy'],['ASSISTÊNCIA','Pedro']]},
    3:{title:'JOGO 03 · VS R DAS FONTES FC',score:'6–0',result:'VITÓRIA',away:'R DAS FONTES FC',badge:'RDF',events:[['GOLOS','Nightface ×4'],['GOLOS','Teddy ×2']]},
    4:{title:'JOGO 04 · VS VISEU ESPORTS',score:'0–0',result:'DERROTA',away:'VISEU ESPORTS',badge:'VFC',note:'Penáltis: 7–8 · derrota nos penáltis',events:[]}
  };

  window.openMatch=function(id){
    const m=matchData[String(id)];
    const modal=document.getElementById('matchModal');
    if(!m||!modal)return false;

    const set=(id,v)=>{
      const e=document.getElementById(id);
      if(e)e.textContent=v;
    };

    set('matchModalTitle',m.title);
    set('modalScore',m.score);
    set('modalResult',m.result);
    set('modalAwayName',m.away);
    set('modalAwayVisual',m.badge);
    set('modalNote',m.note||'');

    const events=document.getElementById('modalEvents');
    if(events){
      events.innerHTML=m.events.map(x =>
        '<div class="modal-event"><strong>'+x[0]+'</strong><span>'+x[1]+'</span></div>'
      ).join('');
    }

    modal.classList.add('open');
    modal.setAttribute('aria-hidden','false');
    return false;
  };

  window.closeMatch=function(){
    const modal=document.getElementById('matchModal');
    if(modal){
      modal.classList.remove('open');
      modal.setAttribute('aria-hidden','true');
    }
  };

  document.addEventListener('keydown',function(e){
    const game=e.target.closest && e.target.closest('.tournament-game');
    if(game && (e.key==='Enter'||e.key===' ')){
      e.preventDefault();
      window.openMatch(game.getAttribute('data-match'));
    }
    if(e.key==='Escape') window.closeMatch();
  });

  document.addEventListener('click',function(e){
    if(e.target.closest && e.target.closest('#matchModalClose')){
      e.preventDefault();
      window.closeMatch();
      return;
    }
    if(e.target.id==='matchModal'){
      window.closeMatch();
    }
  });
})();
